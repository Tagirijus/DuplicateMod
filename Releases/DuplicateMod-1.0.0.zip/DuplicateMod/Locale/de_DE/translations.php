<?php

return array(
    'Duplicate (instant)' => 'Duplizieren (sofort)',
);
