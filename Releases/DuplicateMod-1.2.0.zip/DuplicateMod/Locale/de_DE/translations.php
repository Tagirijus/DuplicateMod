<?php

return array(
    'Duplicate (instant)' => 'Duplizieren (sofort)',
    'DuplicateMod configuration' => 'DuplicateMod Einstellungen',
    'Prefix for duplicated task (leave empty for none).' => 'Prefix für den duplizierten Task (leer lassen für keinen).',
    '[Need WeekHelper plugin!!] Add one week to the week pattern in the tasktitle.' => '[Benötigt das WeekHelper Plugin!!] Addiere eine Woche im Week-Pattern im Tasktitel.',
    'Add days to due date on duplication (leave empty and the due date will be removed on duplication).' => 'Füge Tage zum Due-Date hinzu, wenn der Task dupliziert wird (leer lassen, sodass das Due-Date beim Duplizieren gelöscht wird).',
    'number or leave blank' => 'Zahl oder leer lassen',
);
