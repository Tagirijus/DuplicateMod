<li <?= $this->app->checkMenuSelection('DuplicateModController', 'showConfig') ?>>
    <a href="/duplicatemod/config"><?= t('DuplicateMod configuration') ?></a>
</li>
