<li>
    <?= $this->modal->small('files-o', t('Duplicate (instant)'), 'DuplicateModController', 'duplicateInstant', array('task_id' => $task['id'], 'plugin' => 'DuplicateMod')) ?>
</li>