<?php

return array(
    'Duplicate (instant)' => 'Duplizieren (sofort)',
    'DuplicateMod configuration' => 'DuplicateMod Einstellungen',
    'Prefix for duplicated task (leave empty for none).' => 'Prefix für den duplizierten Task (leer lassen für keinen).',
    '[Need WeekHelper plugin!!] Add one week to the week pattern in the tasktitle.' => '[Benötigt das WeekHelper Plugin!!] Addiere eine Woche im Week-Pattern im Tasktitel.',
);
